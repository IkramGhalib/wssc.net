<?php
$subdivid = "26217";
  $dbtype = "electrocure";
?>