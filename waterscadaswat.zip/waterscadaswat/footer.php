
  <footer class="main-footer">

    <strong>Copyright &copy; 2018-<?php echo date("Y"); ?><a href="Https://www.cisnr.com"> CISNR, UET Peshawar</a>. All rights reserved.</strong>
  </footer>
